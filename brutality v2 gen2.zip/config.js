require("./all/module")

// SETTING KONTAK
global.owner = "6283841442289"
global.ownername = "𝐃𝐢𝐤𝐚 𝐈𝐃"

// GOSAH DI OTAK ATIK
global.autoJoin = false
global.antilink = false
global.codeInvite = ""
global.jumlah = ""

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})