require("./global")

const language = {
onlyprem: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘱𝘳𝘦𝘮𝘪𝘶𝘮*",
onlyown: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘰𝘸𝘯𝘦𝘳*",
onlygroup: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘥𝘪 𝘨𝘳𝘶𝘱*",
onlyadmin: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘢𝘥𝘮𝘪𝘯*",
notext: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘔𝘢𝘯𝘢 𝘵𝘦𝘬𝘴𝘯𝘺𝘢*",
noadmin: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘉𝘰𝘵 𝘣𝘦𝘭𝘶𝘮 𝘮𝘦𝘯𝘫𝘢𝘥𝘪 𝘢𝘥𝘮𝘪𝘯*",
succes: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘋𝘰𝘯𝘦 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬*",
invalid: "\`[ # ] 𝘿𝙄𝙆𝘼 𝙄𝘿\` \n*𝘔𝘢𝘴𝘶𝘬𝘬𝘢𝘯 𝘯𝘰𝘮𝘰𝘳 𝘺𝘢𝘯𝘨 𝘷𝘢𝘭𝘪𝘥*",
}

global.language = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})